import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import APIKeys from './pages/APIKeys'
import Projects from './pages/Projects'
import Tasks from './pages/Tasks'
import History from './pages/History'
import Stats from './pages/Stats'
import './styles.css'

function App(){ 
  return (<BrowserRouter>
    <div className="app">
      <nav className="nav">
        <Link to="/">API Keys</Link>
        <Link to="/projects">Projects</Link>
        <Link to="/tasks">Tasks</Link>
        <Link to="/history">History</Link>
        <Link to="/stats">Stats</Link>
      </nav>
      <main className="main">
        <Routes>
          <Route path="/" element={<APIKeys/>} />
          <Route path="/projects" element={<Projects/>} />
          <Route path="/tasks" element={<Tasks/>} />
          <Route path="/history" element={<History/>} />
          <Route path="/stats" element={<Stats/>} />
        </Routes>
      </main>
    </div>
  </BrowserRouter>)
}

createRoot(document.getElementById('root')).render(<App />)
