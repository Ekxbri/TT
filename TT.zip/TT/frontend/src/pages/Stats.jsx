import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function Stats(){
  const [rows, setRows] = useState([])
  const load = async ()=>{ const r = await axios.get('/api/stats'); setRows(r.data) }
  useEffect(()=>{ load() },[])
  return (<div>
    <h1>Stats</h1>
    <table>
      <thead><tr><th>Project</th><th>Task</th><th>Model</th><th>Tokens</th><th>Cost</th></tr></thead>
      <tbody>
        {rows.map((r,i)=>(<tr key={i}><td>{r.project_id}</td><td>{r.task_id}</td><td>{r.model}</td><td>{r.tokens}</td><td>{r.cost.toFixed(6)}</td></tr>))}
      </tbody>
    </table>
  </div>)
}
