import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function History(){
  const [items, setItems] = useState([])
  const load = async ()=>{
    const r = await axios.get('/api/history')
    setItems(r.data)
  }
  useEffect(()=>{ load() },[])
  return (<div>
    <h1>History</h1>
    <ul className="list">
      {items.map(it=> (<li key={it.ID}>Task {it.TaskID} Prompt {it.PromptID} Model {it.Model} Tokens {it.Tokens} Cost ${it.CostUSD} — {it.Output}</li>))}
    </ul>
  </div>)
}
