import React, {useEffect, useState} from 'react'
import axios from 'axios'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'

export default function Tasks(){
  const [tasks, setTasks] = useState([])
  const [name, setName] = useState('')
  const [selectedTask, setSelectedTask] = useState(null)
  const [prompts, setPrompts] = useState([])
  const [promptForm, setPromptForm] = useState({name:'', model:'gpt-sim', text:''})

  const load = async ()=>{
    const r = await axios.get('/api/tasks')
    setTasks(r.data)
  }
  useEffect(()=>{ load() },[])

  const createTask = async (e)=>{
    e.preventDefault()
    await axios.post('/api/tasks', {name, description:'', api_method:'', version:'1', project_id:0})
    setName(''); load()
  }

  const selectTask = async (t)=>{
    setSelectedTask(t)
    const r = await axios.get('/api/tasks/'+t.ID+'/prompts')
    setPrompts(r.data)
  }

  const addPrompt = async (e)=>{
    e.preventDefault()
    await axios.post('/api/tasks/'+selectedTask.ID+'/prompts', {name: promptForm.name, model: promptForm.model, text: promptForm.text})
    setPromptForm({name:'', model:'gpt-sim', text:''})
    selectTask(selectedTask)
  }

  const onDragEnd = async (result)=>{
    if(!result.destination) return
    const newOrder = Array.from(prompts)
    const [moved] = newOrder.splice(result.source.index,1)
    newOrder.splice(result.destination.index,0,moved)
    setPrompts(newOrder)
    const order = newOrder.map(p=>p.ID)
    await axios.put('/api/tasks/'+selectedTask.ID+'/prompts/order', {order})
  }

  const runTask = async ()=>{
    const r = await axios.post('/api/tasks/'+selectedTask.ID+'/run')
    alert('Run complete. total tokens: '+r.data.total_tokens+' cost: $'+r.data.total_cost)
  }

  return (<div>
    <h1>Tasks</h1>
    <div style={{display:'flex',gap:20}}>
      <div style={{flex:1}}>
        <form onSubmit={createTask} className="form">
          <input value={name} onChange={e=>setName(e.target.value)} placeholder="task name"/>
          <button type="submit">Create Task</button>
        </form>
        <ul className="list">
          {tasks.map(t=> <li key={t.ID}><button onClick={()=>selectTask(t)}>{t.Name}</button></li>)}
        </ul>
      </div>
      <div style={{flex:2}}>
        {selectedTask ? (<div>
          <h2>{selectedTask.Name}</h2>
          <form onSubmit={addPrompt} className="form">
            <input value={promptForm.name} onChange={e=>setPromptForm({...promptForm,name:e.target.value})} placeholder="prompt name"/>
            <input value={promptForm.model} onChange={e=>setPromptForm({...promptForm,model:e.target.value})} placeholder="model"/>
            <input value={promptForm.text} onChange={e=>setPromptForm({...promptForm,text:e.target.value})} placeholder="prompt text"/>
            <button type="submit">Add Prompt</button>
          </form>
          <button onClick={runTask}>Run Task</button>
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="prompts">
              {(provided)=> (<ul className="list" ref={provided.innerRef} {...provided.droppableProps}>
                {prompts.map((p, idx)=> (<Draggable key={p.ID} draggableId={String(p.ID)} index={idx}>
                  {(prov)=> (<li ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps}>{p.Name} — {p.Model}<button style={{marginLeft:10}} onClick={async()=>{await axios.delete('/api/prompts/'+p.ID); selectTask(selectedTask)}}>Delete</button></li>)}
                </Draggable>))}
                {provided.placeholder}
              </ul>)}
            </Droppable>
          </DragDropContext>
        </div>) : (<div>Select a task to edit prompts</div>)}
      </div>
    </div>
  </div>)
}
