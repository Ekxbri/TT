import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function Projects(){
  const [items, setItems] = useState([])
  const [name, setName] = useState('')
  const load = async ()=>{
    const r = await axios.get('/api/projects')
    setItems(r.data)
  }
  useEffect(()=>{ load() },[])
  const submit = async (e)=>{
    e.preventDefault()
    await axios.post('/api/projects', {name, api_key:'', status:'active'})
    setName('')
    load()
  }
  const del = async (id)=>{ await axios.delete('/api/projects/'+id); load() }

  return (<div>
    <h1>Projects</h1>
    <form onSubmit={submit} className="form">
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="project name"/>
      <button type="submit">Create</button>
    </form>
    <ul className="list">
      {items.map(p=> <li key={p.ID}>{p.Name} <button onClick={()=>del(p.ID)}>Delete</button></li>)}
    </ul>
  </div>)
}
