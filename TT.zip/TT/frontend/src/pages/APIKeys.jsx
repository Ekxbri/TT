import React, {useEffect, useState} from 'react'
import axios from 'axios'

export default function APIKeys(){
  const [keys, setKeys] = useState([])
  const [form, setForm] = useState({provider:'openai', name:'', value:''})

  const load = async ()=>{
    const r = await axios.get('/api/keys')
    setKeys(r.data)
  }
  useEffect(()=>{ load() },[])

  const submit = async (e)=>{
    e.preventDefault()
    await axios.post('/api/keys', form)
    setForm({provider:'openai', name:'', value:''})
    load()
  }

  const del = async (id)=>{
    await axios.delete('/api/keys/'+id)
    load()
  }

  return (<div>
    <h1>API Keys</h1>
    <form onSubmit={submit} className="form">
      <input value={form.provider} onChange={e=>setForm({...form, provider:e.target.value})} placeholder="provider"/>
      <input value={form.name} onChange={e=>setForm({...form, name:e.target.value})} placeholder="name"/>
      <input value={form.value} onChange={e=>setForm({...form, value:e.target.value})} placeholder="value"/>
      <button type="submit">Add</button>
    </form>
    <ul className="list">
      {keys.map(k=> <li key={k.ID}>{k.Name} ({k.Provider}) <button onClick={()=>del(k.ID)}>Delete</button></li>)}
    </ul>
  </div>)
}
