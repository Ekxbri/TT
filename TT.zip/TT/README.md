AI Hub - Complete prototype v2 (Backend: Go, Frontend: React + Vite)

Features added:
 - Prompts constructor with drag&drop
 - Prompt history storage
 - Run task endpoint (simulated LLM calls)
 - Simple stats aggregation (tokens & cost)

Backend (port 8080)
  cd backend
  go mod tidy
  go run cmd/server/main.go

Frontend (port 5173)
  cd frontend
  npm install
  npm run dev

API endpoints (new):
  GET /api/tasks/:id/prompts
  POST /api/tasks/:id/prompts
  PUT /api/tasks/:id/prompts/order
  POST /api/tasks/:id/run
  GET /api/history
  GET /api/stats

Notes:
 - LLM calls are simulated (no external API keys required). Token counting is naive (word count).
 - Costs are simulated: cost = tokens * 0.0001 USD
 - For production, replace simulateLLMResponse with real provider integrations and add auth.
